# 来源、事实与官方图片

事件2026-09-29，查证截至2026-09-30。主体事实沿用已核对的官方原文，未独立复现性能评测。图上的长条件压缩后，完整细节继续保留在本文件和coverage.md。

## [S1] DevDay 2026 Recap

- [原文](https://openai.com/index/devday-2026-recap/)
- 发布时间：2026-09-29；查证：2026-09-30
- 范围与完整性基准：官方回顾的 25 个产品主题；官方总述为 20 多项发布。

## [S2] Introducing dots

- [原文](https://openai.com/index/introducing-dots/)
- 发布时间：2026-09-29；查证：2026-09-30
- 能力、专用 dots 预览、Microsoft Agent 365、可用性与用量。

## [S3] Dots privacy, security, and safety FAQs

- [原文](https://help.openai.com/en/articles/20001529-dots-privacy-security-and-safety-faqs)
- 发布时间：动态文档；未标独立首发日；查证：2026-09-30
- 后台主动研究的只读边界、权限和 Custom Rules。

## [S4] Introducing GPT-6.1 Sol

- [原文](https://openai.com/index/introducing-gpt-6-1-sol/)
- 发布时间：2026-09-29；查证：2026-09-30
- 五类评测与限制、上线范围；模型研究评测，不是本篇实测。

## [S5] GPT-6.1 Sol model

- [原文](https://developers.openai.com/api/docs/models/gpt-6.1-sol)
- 发布时间：动态文档；未标独立首发日；查证：2026-09-30
- 价格、272K 输入分界、采样和推理设置、工具接口。

## [S6] Speed: Ultrafast in Work and Codex

- [原文](https://learn.chatgpt.com/docs/agent-configuration/speed)
- 发布时间：动态文档；未标独立首发日；查证：2026-09-30
- Codex 速度与订阅/credits 倍率分别核对。

## [S7] ZDR with Private Safety Processing

- [原文](https://developers.openai.com/api/docs/guides/private-safety-processing)
- 发布时间：动态文档；未标独立首发日；查证：2026-09-30
- 客户控制存储；硬件认证的安全审阅；并不表示客户侧不保存记录。

## [S8] Codex Cloud

- [原文](https://learn.chatgpt.com/docs/cloud)
- 发布时间：动态文档；未标独立首发日；查证：2026-09-30
- 云端开发环境、复用项目设置与独立任务工作区。

## [S9] Codex CLI

- [原文](https://learn.chatgpt.com/docs/codex/cli)
- 发布时间：动态文档；未标独立首发日；查证：2026-09-30
- CLI 工作流；本篇只采用大会回顾列出的语音、/agents 与交互变化。

## [S10] Code review

- [原文](https://learn.chatgpt.com/docs/code-review?surface=app)
- 发布时间：动态文档；未标独立首发日；查证：2026-09-30
- 桌面审查、GitHub GA、GitLab 预览和自动云端审查。

## [S11] Codex Security Cloud setup

- [原文](https://learn.chatgpt.com/docs/security/setup)
- 发布时间：动态文档；未标独立首发日；查证：2026-09-30
- GitHub 仓库扫描、持续监控与修复建议；Daybreak Blue 可用性参见大会回顾。

## [S12] Amazon Bedrock Managed Agents, powered by OpenAI

- [原文](https://aws.amazon.com/bedrock/managed-agents-openai/)
- 发布时间：动态文档；未标独立首发日；查证：2026-09-30
- AWS 联合发布原文，标题明确 Preview，运行时与推理都位于 AWS。

## [S13] Plugin Extensions

- [原文](https://developers.openai.com/plugins/build/extensions)
- 发布时间：动态文档；未标独立首发日；查证：2026-09-30
- 侧栏、对话面板、文件查看器等扩展；Free/Go 网页端即将推出。

## [S14] Upload and submit your plugin

- [原文](https://developers.openai.com/plugins/deploy/submission)
- 发布时间：动态文档；未标独立首发日；查证：2026-09-30
- Plugin Creator 与提交检查反馈；排名/推荐改进来自大会回顾。

## [S15] Sites in ChatGPT

- [原文](https://chatgpt.com/features/sites/)
- 发布时间：动态文档；未标独立首发日；查证：2026-09-30
- Sites 产品与连接应用；本篇聚焦大会宣布的托管插件及自动化改进。

## [S16] MCP Events

- [原文](https://developers.openai.com/plugins/build/mcp-events)
- 发布时间：动态文档；未标独立首发日；查证：2026-09-30
- MCP 2.0 2026-07-28；Webhook 与回调验证；不支持 polling/streaming。

## [S17] ChatGPT Space

- [原文](https://chatgpt.com/features/space/)
- 发布时间：动态文档；未标独立首发日；查证：2026-09-30
- Space、Pages、协作、移动端范围；协作幻灯片和表格 coming soon。

## [S18] Set up and manage teams and Team Tasks

- [原文](https://learn.chatgpt.com/docs/enterprise/teams)
- 发布时间：动态文档；未标独立首发日；查证：2026-09-30
- 团队服务账号、共享连接、计划/事件触发与团队额度。

## [S19] ChatGPT in Slack and Microsoft Teams

- [原文](https://chatgpt.com/features/chatgpt-in-slack-and-teams/)
- 发布时间：动态文档；未标独立首发日；查证：2026-09-30
- 无需个人 license；管理员接入，个人权限不自动继承。

## [S20] The Meetings plugin in ChatGPT

- [原文](https://help.openai.com/en/articles/20001546-the-meetings-plugin-in-chatgpt)
- 发布时间：动态文档；未标独立首发日；查证：2026-09-30
- macOS Beta、会议同意、默认私有、音频完成处理后删除。

## [S21] Shareable profiles in ChatGPT

- [原文](https://help.openai.com/en/articles/20001539-shareable-profiles-in-chatgpt)
- 发布时间：动态文档；未标独立首发日；查证：2026-09-30
- 网页/桌面 showcase；企业共享仍 coming soon，个人不分享技能。

## [S22] Using your ChatGPT plan in other apps and sites

- [原文](https://help.openai.com/en/articles/20001542-using-your-chatgpt-plan-in-other-apps-and-sites)
- 发布时间：动态文档；未标独立首发日；查证：2026-09-30
- 账号登录与订阅额度授权分开；额度上限和第三方费用。

## [S23] Sign in with ChatGPT partner directory

- [原文](https://learn.chatgpt.com/docs/sign-in-with-chatgpt)
- 发布时间：动态文档；未标独立首发日；查证：2026-09-30
- 16 个额度伙伴：12 个商业工具（含 Lovable coming soon）+ 4 个开源集成；另有只登录工具。

## [S24] About ChatGPT Pro tiers

- [原文](https://help.openai.com/en/articles/9793128-about-chatgpt-pro-tiers)
- 发布时间：动态文档；未标独立首发日；查证：2026-09-30
- Pro 500 美元/月、Pro 200 重新开放与已有额度过渡至 10/29。

## [S25] OpenAI Marketplace

- [原文](https://openai.com/business/marketplace/)
- 发布时间：动态文档；未标独立首发日；查证：2026-09-30
- 企业承诺额度抵扣合作产品，资格依合同、产品与项目条款。

## [S26] API Ultrafast mode

- [原文](https://developers.openai.com/api/docs/guides/ultrafast-mode)
- 发布时间：动态文档；未标独立首发日；查证：2026-09-30
- API 配置、速率与地域；文档写 up to 8x，大会回顾 API 写 up to 6x，卡片明确沿用大会口径。

## [S27] API Pricing

- [原文](https://developers.openai.com/api/docs/pricing)
- 发布时间：动态文档；未标独立首发日；查证：2026-09-30
- Standard 模型单价；独立核对缓存写入、长输入、地域和档位。

## [S28] GPT-6.1 Sol system card addendum

- [原文](https://deploymentsafety.openai.com/gpt-6-1-sol)
- 发布时间：动态文档；未标独立首发日；查证：2026-09-30
- 挑战性对齐测试及典型用法限制；不用挑战集推断日常故障率。

## [S29] Agents API Computer use

- [原文](https://developers.openai.com/api/docs/guides/agents-api/tools/computer-use)
- 发布时间：动态文档；未标独立首发日；查证：2026-09-30
- 托管电脑/浏览器交互、应用负责网站授权与登录。

## [S30] OpenAI DevDay 2026 event

- [原文](https://devday.openai.com/)
- 发布时间：动态文档；未标独立首发日；查证：2026-09-30
- 大会当地日期 9/29、旧金山 Fort Mason；本篇事件日期按太平洋时间。

## 完整事实核对表

| ID | 原文判断 | 类型 | 来源 | 新版页码 | 条件与口径 |
|---|---|---|---|---|---|
| p3-1 | 24/7 与自己的电脑: 配备云端电脑和浏览器，可处理多个项目； 通过插件生态连接 4,000 多个应用。 | official announcement/docs | S2, S1 | 2 | 合资格市场 Pro / Business Premium；Enterprise、Edu、Healthcare Beta 需管理员开启，默认关闭。 |
| p3-2 | 跨渠道沟通: 在 ChatGPT、Slack、Teams 交流，也能语音通话； 短信即将推出，可授权连接你的电脑。 | official announcement/docs | S2, S1 | 2 | 合资格市场 Pro / Business Premium；Enterprise、Edu、Healthcare Beta 需管理员开启，默认关闭。 |
| p3-3 | 专用 Dots · 企业预览: 独立身份、凭据与明确职责； 启动企业试点，并与 Microsoft Agent 365 集成。 | official announcement/docs | S2, S1 | 2 | 合资格市场 Pro / Business Premium；Enterprise、Edu、Healthcare Beta 需管理员开启，默认关闭。 |
| p4-1 | 主动研究使用只读工具: 可读已授权来源、记私有笔记；这一步不发消息、 不改应用内容，也不控制浏览器或电脑。 | official announcement/docs | S2, S3 | 2 | 深度工作有独立额度；首月提高上限。个人计划的数据设置与工作区默认规则分别适用。 |
| p4-2 | 动作仍要经过审阅: Auto-review 按指令、规则和安全要求判断； 改密码等敏感操作由用户完成。 | official announcement/docs | S2, S3 | 2 | 深度工作有独立额度；首月提高上限。个人计划的数据设置与工作区默认规则分别适用。 |
| p4-3 | 对话与任务分别计量: 首个 dot 随 Pro / Business Premium 包含。 对话不占 ChatGPT 用量；发起 Work / Codex 任务照常计量。 | official announcement/docs | S2, S3 | 2 | 深度工作有独立额度；首月提高上限。个人计划的数据设置与工作区默认规则分别适用。 |
| p6-1 | DeepSWE v1.1 · 代码: 达到 Astra 的成绩、约 1/5 任务成本； 比原 Sol 最好成绩高 6.4 个百分点。 | official announcement/docs | S4 | 3, 4 | 官方研究环境 / API 测试；任务、推理设置与成本口径分别核对。 |
| p6-2 | GDP.pdf · 专业文档: 比带 fallbacks 的 Opus 5.5 高、任务成本低于一半； 接近 Astra 成绩，约 1/5 任务成本。 | official announcement/docs | S4 | 3, 4 | 官方研究环境 / API 测试；任务、推理设置与成本口径分别核对。 |
| p6-3 | AutomationBench · 工作流: medium：比 Opus 高 2.2 个百分点、约 1/3 成本； 比原 Sol 同设置高 4.8 个百分点。 | official announcement/docs | S4 | 3, 4 | 官方研究环境 / API 测试；任务、推理设置与成本口径分别核对。 |
| p6-4 | OSWorld 2.0 · 电脑操作: offline 集、max effort：比 Sol 高 7 个百分点； 距 Astra 2.1 个百分点、约 1/7 任务成本。 | official announcement/docs | S4 | 3, 4 | 官方研究环境 / API 测试；任务、推理设置与成本口径分别核对。 |
| p7-1 | 科研任务 · max effort: 成绩超过原 Sol 的两倍；每任务平均 $5.47， 对比 Opus $23.21、Astra $23.80。Astra 仍为最高分。 | official announcement/docs | S4, S5, S28 | 3, 4 | Work / Codex：Plus、Pro、Business、Enterprise、Edu。 推理支持 low–max；接工具用 Responses API。 |
| p7-2 | 事实性 · low effort: 含事实错误的回答占比由 11.4% 降至 7.7%。 提示来自用户曾标记错误的对话，不代表典型使用。 | official announcement/docs | S4, S5, S28 | 3, 4 | Work / Codex：Plus、Pro、Business、Enterprise、Edu。 推理支持 low–max；接工具用 Responses API。 |
| p7-3 | 对齐测试: 透明披露限制、遵守明确要求等挑战测试改善； 不能把挑战测试失败率套用到日常工作。 | official announcement/docs | S4, S5, S28 | 3, 4 | Work / Codex：Plus、Pro、Business、Enterprise、Edu。 推理支持 low–max；接工具用 Responses API。 |
| p8-1 | Astra 已开放: API 可用；Work / Codex 面向 Pro 500 与 合资格企业计划，按权限和地域开放。 | official announcement/docs | S1, S6, S26 | 5 | 最高倍数不能保证任务总耗时等比缩短。API 文档另写最高 8×；本页明确采用大会 API 6× 表述。 |
| p8-2 | 6.1 Sol Ultrafast · 即将推出: 大会宣布 coming soon， 不要把现有 Standard / Fast 当成 Ultrafast 已上线。 | official announcement/docs | S1, S6, S26 | 5 | 最高倍数不能保证任务总耗时等比缩短。API 文档另写最高 8×；本页明确采用大会 API 6× 表述。 |
| p8-3 | 速度和账单分别核对: Astra 的订阅额度按 Standard 的 8× 消耗； 购买 credits / 企业按量账单按 6×，另依合同。 | official announcement/docs | S1, S6, S26 | 5 | 最高倍数不能保证任务总耗时等比缩短。API 文档另写最高 8×；本页明确采用大会 API 6× 表述。 |
| p9-1 | ZDR + Private Safety Processing: 自动安全审阅在受保护的运行时完成， OpenAI 人员无法读取受保护的客户内容。 | official announcement/docs | S1, S7 | 6 | “OpenAI 零数据保留”与“客户侧保存安全记录”同时成立；接入资格和配置见官方指南。 |
| p9-2 | 客户控制保存和密钥: 加密安全记录保存在客户云端存储； 当前方案要求至少保留 30 天，权限由客户管理。 | official announcement/docs | S1, S7 | 6 | “OpenAI 零数据保留”与“客户侧保存安全记录”同时成立；接入资格和配置见官方指南。 |
| p9-3 | Private Inference · 秋季预览: 结合 confidential computing 与可验证控制； 大会尚未宣布普遍开放。 | official announcement/docs | S1, S7 | 6 | “OpenAI 零数据保留”与“客户侧保存安全记录”同时成立；接入资格和配置见官方指南。 |
| p10-1 | 环境只配置一次: 保存仓库、依赖、工具、网络与获准设置， 让后续任务复用团队的开发准备。 | official announcement/docs | S8, S1 | 7 | 大会列 Plus、Pro、Business、Healthcare、Education、Enterprise；具体访问依工作区设置。 |
| p10-2 | 每个任务有自己的工作区: 共享环境设置，独立处理修改； 任务结束后检查代码和测试结果。 | official announcement/docs | S8, S1 | 7 | 大会列 Plus、Pro、Business、Healthcare、Education、Enterprise；具体访问依工作区设置。 |
| p10-3 | 更灵活的运行入口: 本地电脑、手机远程、云端各取所需； 云端环境连接 GitHub 并按项目权限配置。 | official announcement/docs | S8, S1 | 7 | 大会列 Plus、Pro、Business、Healthcare、Education、Enterprise；具体访问依工作区设置。 |
| p11-1 | 语音指导: 用语音发起任务，也能在工作中补充要求。 | official announcement/docs | S1, S9 | 7 | 大会列所有计划；客户端、构建与具体快捷键仍以对应版本为准。 |
| p11-2 | /agents 任务视图: 更方便委派工作，跟踪同时进行的多个任务。 | official announcement/docs | S1, S9 | 7 | 大会列所有计划；客户端、构建与具体快捷键仍以对应版本为准。 |
| p11-3 | 日常操作与显示: 改进提示编辑、恢复会话、worktree； 终端界面更清楚，长会话更易阅读。 | official announcement/docs | S1, S9 | 7 | 大会列所有计划；客户端、构建与具体快捷键仍以对应版本为准。 |
| p12-1 | 跨项目审查入口: 个人 inbox 集中找需要处理的请求； 查看改动文件、评论、检查状态与相关 PR。 | official announcement/docs | S10, S1 | 8 | 所有计划；GitHub GA，GitLab 支持仍为预览。自动审查结果需要结合 diff 核验。 |
| p12-2 | 和 Codex 一起检查: 在审查对话中解释变更、调查发现， 用 review instructions 统一关注点。 | official announcement/docs | S10, S1 | 8 | 所有计划；GitHub GA，GitLab 支持仍为预览。自动审查结果需要结合 diff 核验。 |
| p12-3 | 自动云端审查: 离开电脑时也能先检查； 需要仓库连接、权限和自动审查设置。 | official announcement/docs | S10, S1 | 8 | 所有计划；GitHub GA，GitLab 支持仍为预览。自动审查结果需要结合 diff 核验。 |
| p13-1 | 一次、定时、持续检查: 扫描整个仓库，或监控新 commit； 选择云环境并查看证据和优先级。 | official announcement/docs | S11, S1 | 8 | Pro、Business、Enterprise、Edu；桌面和网页可用，仍需 GitHub 与工作区访问权限。 |
| p13-2 | 生成修复建议: 可用 Fix with Codex 准备 patch； 审查之后再创建 draft PR。 | official announcement/docs | S11, S1 | 8 | Pro、Business、Enterprise、Edu；桌面和网页可用，仍需 GitHub 与工作区访问权限。 |
| p13-3 | Daybreak Blue 模型: 大会说明无需单独申请 Daybreak； 云端插件与本地安全扫描是不同入口。 | official announcement/docs | S11, S1 | 8 | Pro、Business、Enterprise、Edu；桌面和网页可用，仍需 GitHub 与工作区访问权限。 |
| p14-1 | 输入与返回: 提交文本或图像上下文， 从开发者定义的有限答案中做判断。 | official announcement/docs | S1 | 9 | 官方回顾尚未给出完整价格和延迟数字，本篇不推测。 |
| p14-2 | 当前状态: Limited preview；大会说明 未来几天计划扩大开放。 | official announcement/docs | S1 | 9 | 官方回顾尚未给出完整价格和延迟数字，本篇不推测。 |
| p15-1 | 托管电脑与浏览器: 读取页面、操作界面； 网站授权与账号登录由应用处理。 | official announcement/docs | S29, S1 | 9 | API 接入；大会另列 Work / Codex 的 Pro 500 与 Enterprise。Agents API 本身仍按 Beta 文档接入。 |
| p15-2 | Codex 的编排能力: 并行子任务、工具检索与调用、 上下文压缩纳入应用工作流。 | official announcement/docs | S29, S1 | 9 | API 接入；大会另列 Work / Codex 的 Pro 500 与 Enterprise。Agents API 本身仍按 Beta 文档接入。 |
| p15-3 | 接入边界: 模型、工具与运行环境按使用方式计费； 操作权限和结果核验要落到你的应用。 | official announcement/docs | S29, S1 | 9 | API 接入；大会另列 Work / Codex 的 Pro 500 与 Enterprise。Agents API 本身仍按 Beta 文档接入。 |
| p16-1 | 保留核心 Agent 能力: 持续上下文、工具与专门 Agent 的协调， 适用于需要多步处理的长任务。 | official announcement/docs | S12, S1 | 10 | AWS 联合产品目前为 Preview，接入依 AWS 身份、权限与资源设置。 |
| p16-2 | AWS 原生连接: 运行时和模型推理都在 AWS； 接入已有计算、数据资源和治理控制。 | official announcement/docs | S12, S1 | 10 | AWS 联合产品目前为 Preview，接入依 AWS 身份、权限与资源设置。 |
| p16-3 | 按身份控制访问: 每个 Agent 有 AWS 身份和明确权限； AgentCore 提供默认计算环境。 | official announcement/docs | S12, S1 | 10 | AWS 联合产品目前为 Preview，接入依 AWS 身份、权限与资源设置。 |
| p17-1 | 侧栏应用: 让插件有一个可打开、全屏使用的入口。 | official announcement/docs | S13, S1 | 11 | 大会列所有计划；文档标 Free / Go 网页扩展 coming soon，输入框 mentions 仅桌面。 |
| p17-2 | 对话旁的交互面板: 应用操作与对话并排， 保持工作内容和讨论在同一个界面。 | official announcement/docs | S13, S1 | 11 | 大会列所有计划；文档标 Free / Go 网页扩展 coming soon，输入框 mentions 仅桌面。 |
| p17-3 | 文件查看器等扩展: 展示你的产品支持的文件类型； 另有设置和输入框相关扩展。 | official announcement/docs | S13, S1 | 11 | 大会列所有计划；文档标 Free / Go 网页扩展 coming soon，输入框 mentions 仅桌面。 |
| p18-1 | Plugin Creator: 辅助准备插件、组织工具与技能， 按产品文档完成可分发的 package。 | official announcement/docs | S14, S1 | 11 | 大会列所有计划；能力与提交流程已核对官方回顾及发布文档。 |
| p18-2 | 更清楚的提交反馈: 上传 ZIP 后查看检查发现、修正问题， 通过审核后由开发者选择发布时间。 | official announcement/docs | S14, S1 | 11 | 大会列所有计划；能力与提交流程已核对官方回顾及发布文档。 |
| p18-3 | 目录排名与推荐: 改善目录与对话中的相关插件发现； 用户选择安装，并批准每个插件的访问。 | official announcement/docs | S14, S1 | 11 | 大会列所有计划；能力与提交流程已核对官方回顾及发布文档。 |
| p19-1 | 同一个应用，各自的数据: 同事使用自己的连接与权限， 不用共用创作者的个人账号。 | official announcement/docs | S15, S1 | 12 | 大会列 Business、Enterprise、Healthcare、Edu；支持的插件与访问范围依工作区设置。 |
| p19-2 | 自动化更好配置: 更容易添加和管理自动化， 让共享信息持续更新。 | official announcement/docs | S15, S1 | 12 | 大会列 Business、Enterprise、Healthcare、Edu；支持的插件与访问范围依工作区设置。 |
| p19-3 | 从制作到分享: 在 ChatGPT 中描述、迭代并发布站点， 按工作区的访问和连接设置分享。 | official announcement/docs | S15, S1 | 12 | 大会列 Business、Enterprise、Healthcare、Edu；支持的插件与访问范围依工作区设置。 |
| p20-1 | 订阅你关注的事件: 比如项目看板出现新任务， 读关联资料并准备计划。 | official announcement/docs | S16, S1 | 12 | 大会列所有计划；基于拟议的 MCP Events 规范，接入方式以当前文档为准。 |
| p20-2 | 后台也能响应: 用户定义监控内容和要做的事； Webhook 通知驱动已授权的后续工作。 | official announcement/docs | S16, S1 | 12 | 大会列所有计划；基于拟议的 MCP Events 规范，接入方式以当前文档为准。 |
| p20-3 | 协议与当前范围: MCP 2.0（2026-07-28），支持回调验证； 此集成暂不支持 polling / streaming。 | official announcement/docs | S16, S1 | 12 | 大会列所有计划；基于拟议的 MCP Events 规范，接入方式以当前文档为准。 |
| p21-1 | 共享知识与工作成果: 汇集 Pages、文件、幻灯片、表格等； 后续任务使用共同上下文。 | official announcement/docs | S17, S1 | 13 | Pro、Business、Enterprise；Space 替代 Library，仍受共享和管理员权限设置约束。 |
| p21-2 | 按指令整理和更新: 告诉 ChatGPT 项目重点和更新要求， 持续整理空间，方便找回工作。 | official announcement/docs | S17, S1 | 13 | Pro、Business、Enterprise；Space 替代 Library，仍受共享和管理员权限设置约束。 |
| p21-3 | 多端的开放范围: 网页与桌面创建、编辑、协作； 手机可查找、阅读、分享，编辑即将推出。 | official announcement/docs | S17, S1 | 13 | Pro、Business、Enterprise；Space 替代 Library，仍受共享和管理员权限设置约束。 |
| p22-1 | 内容不止文字: 组合图片、图表、清单、原型和交互工具， 按任务需要研究与生成内容。 | official announcement/docs | S17, S1 | 13 | Pro、Business、Enterprise；连接来源与页面分享分别受各自权限限制。 |
| p22-2 | 多人实时协作: 邀请同事编辑、评论， @ChatGPT 或 dot 继续修改、处理下一步。 | official announcement/docs | S17, S1 | 13 | Pro、Business、Enterprise；连接来源与页面分享分别受各自权限限制。 |
| p22-3 | 让页面持续更新: 给页面来源与更新指令， 依据已授权连接维护动态内容。 | official announcement/docs | S17, S1 | 13 | Pro、Business、Enterprise；连接来源与页面分享分别受各自权限限制。 |
| p23-1 | 共同编辑与评论: 多个同事和 Agent 可同时编辑， 在同一份 deck 上反馈和修订。 | official announcement/docs | S17, S1 | 14 | Space 产品页同时注明协作表格 coming soon；上线状态以对应功能为准。 |
| p23-2 | 演示与导出: 在 ChatGPT 中演示，或导出 PowerPoint / Google Slides；官方称保留格式。 | official announcement/docs | S17, S1 | 14 | Space 产品页同时注明协作表格 coming soon；上线状态以对应功能为准。 |
| p23-3 | 当前状态: 面向 Pro、Business、Enterprise； 大会明确 coming weeks，尚未普遍开放。 | official announcement/docs | S17, S1 | 14 | Space 产品页同时注明协作表格 coming soon；上线状态以对应功能为准。 |
| p24-1 | 定时或事件触发: 每周项目更新，或新邮件、Slack 消息触发； 同事一起维护任务指令。 | official announcement/docs | S18, S1 | 15 | Business、Enterprise；ChatGPT Teams 与 Microsoft Teams 是不同概念，成员不会自动同步。 |
| p24-2 | 用团队账号运行: 云端任务使用团队 service account 和连接； 管理员决定可用外部账号和权限。 | official announcement/docs | S18, S1 | 15 | Business、Enterprise；ChatGPT Teams 与 Microsoft Teams 是不同概念，成员不会自动同步。 |
| p24-3 | 共享管理和用量: 需要创建 / 管理团队任务的权限； 使用工作区 credits，团队限额与个人限额分开。 | official announcement/docs | S18, S1 | 15 | Business、Enterprise；ChatGPT Teams 与 Microsoft Teams 是不同概念，成员不会自动同步。 |
| p25-1 | 沿着同一个讨论改进: 同事补充背景、纠正细节， 在共享对话中继续修订结果。 | official announcement/docs | S19, S1 | 15 | 大会列 Business / Enterprise，功能页另含 Edu；由管理员设置。共享回复与源文件权限分别核对。 |
| p25-2 | 接入公司或个人工具: 使用管理员配置的连接， 或用户另行授权的个人工具。 | official announcement/docs | S19, S1 | 15 | 大会列 Business / Enterprise，功能页另含 Edu；由管理员设置。共享回复与源文件权限分别核对。 |
| p25-3 | 无需人人有个人 license: 启用频道的成员可使用； 不会自动继承个人账号、全部历史或权限。 | official announcement/docs | S19, S1 | 15 | 大会列 Business / Enterprise，功能页另含 Edu；由管理员设置。共享回复与源文件权限分别核对。 |
| p26-1 | 不需要机器人进会: macOS 桌面插件读取麦克风与系统音频； 开始前取得与会者同意。 | official announcement/docs | S20, S1 | 16 | macOS Beta：Pro、Business；Enterprise 仅有限 alpha，普遍支持及其他系统 coming soon。 |
| p26-2 | 摘要之后接着行动: 结合授权来源丰富记录； 审查行动项，再更新计划或准备跟进稿。 | official announcement/docs | S20, S1 | 16 | macOS Beta：Pro、Business；Enterprise 仅有限 alpha，普遍支持及其他系统 coming soon。 |
| p26-3 | 记录默认私有: 自行决定分享；笔记就绪后删除音频， 不能回放，离线待处理时可能暂存。 | official announcement/docs | S20, S1 | 16 | macOS Beta：Pro、Business；Enterprise 仅有限 alpha，普遍支持及其他系统 coming soon。 |
| p27-1 | 展示与发现: 大会介绍 Sites 和插件的共享展示； 同事也能发现工作区中的共享技能。 | official announcement/docs | S21, S1 | 17 | 大会列 Free 至 Enterprise；帮助页标 Enterprise profiles coming soon，实际开放依 rollout。 |
| p27-2 | 技能与公开分享分开: 技能分享仅限工作区； 个人主页不能公开分享技能。 | official announcement/docs | S21, S1 | 17 | 大会列 Free 至 Enterprise；帮助页标 Enterprise profiles coming soon，实际开放依 rollout。 |
| p27-3 | 访问范围: 网页 / 桌面可管理 showcase； 手机暂无 showcase，个人主页可保持私有。 | official announcement/docs | S21, S1 | 17 | 大会列 Free 至 Enterprise；帮助页标 Enterprise profiles coming soon，实际开放依 rollout。 |
| p28-1 | 16 个额度伙伴: 含 Devin、Notion、Vercel、T3、OpenClaw、Dactyl； 目录包含商业工具与开源集成，Lovable 尚 coming soon。 | official announcement/docs | S22, S23, S1 | 17 | Identity 全球可用；额度仅限参与工具。第三方订阅 / 服务可另外收费，credits 需显式授权。 |
| p28-2 | 额度仍计入原计划: Plus / Pro 可授权符合条件的 AI 请求， 按应用设置每周限额；不会增加总额度。 | official announcement/docs | S22, S23, S1 | 17 | Identity 全球可用；额度仅限参与工具。第三方订阅 / 服务可另外收费，credits 需显式授权。 |
| p28-3 | 更少密码和 API Key: 支持工具可直接用 ChatGPT 账号登录； 连接插件更方便，无需分享 OpenAI API Key。 | official announcement/docs | S22, S23, S1 | 17 | Identity 全球可用；额度仅限参与工具。第三方订阅 / 服务可另外收费，credits 需显式授权。 |
| p29-1 | 包含 Astra Ultrafast: 面向需要更多用量和输出速度的用户， 具体消耗倍率见 Ultrafast 页。 | official announcement/docs | S24, S1 | 5 | 价格单位为美元 / 月。Pro 200 月费仍 $200；既有用户的资格与通知以账号为准。 |
| p29-2 | Pro 三档并列: Pro 100：$100；Pro 200：$200； Pro 500：$500 / 月，只有 500 包含 Ultrafast。 | official announcement/docs | S24, S1 | 5 | 价格单位为美元 / 月。Pro 200 月费仍 $200；既有用户的资格与通知以账号为准。 |
| p29-3 | Pro 200 再开放与额度调整: 不符合 grandfathering 的新订阅额度降低； 符合条件的既有用户保留旧额度至 10/29，之后调整。 | official announcement/docs | S24, S1 | 5 | 价格单位为美元 / 月。Pro 200 月费仍 $200；既有用户的资格与通知以账号为准。 |
| p30-1 | 首批 32 家伙伴: 覆盖创意、客户体验、法律、安全及开源模型； 大会列 Figma、Adobe、Harvey、CrowdStrike 等。 | official announcement/docs | S25, S1 | 18 | Marketplace 是企业采购计划，和安装 ChatGPT 插件的目录分别理解。 |
| p30-2 | 采购额度更灵活: 向 OpenAI 与合作产品表达采购需求， 按资格确认可以使用的承诺额度。 | official announcement/docs | S25, S1 | 18 | Marketplace 是企业采购计划，和安装 ChatGPT 插件的目录分别理解。 |
| p30-3 | 资格取决于条款: 依企业协议、伙伴产品与项目条件； 不是给所有用户的通用消费券。 | official announcement/docs | S25, S1 | 18 | Marketplace 是企业采购计划，和安装 ChatGPT 插件的目录分别理解。 |
| sol-price | 6.1 Sol Standard 输入 $2、缓存输入 $0.10、写入 $2.50、输出 $10 / 百万 token；输入≤272K；Astra 的1/5 | 官方价格 | S5, S27, S4 | 3, 4 | Standard；输入≤272K token；美元 / 百万 token。
缓存输入 $0.10；缓存写入 $2.50。
长输入、工具、地域与其他档位另计。 |

## 本版使用的官方画面

### dots-context

- 文件：assets/dots-context.webp
- [官方页面](https://chatgpt.com/features/dots/) · [原始图片/截图来源](https://images.ctfassets.net/8su2tbn87fck/50i8QJ5a9eoNSc9ZtS9ya/b072f59b9ab0cba2d56dd06b25d6cd3a/bento_context_desktop.png?fm=webp&q=80&w=1920)
- 类型：官方产品演示图；画面：Dot与Google Calendar、Google Drive、GitHub、Charts等连接工具的卡片与官方Dot形象
- 图片未标独立发布日期；关联DevDay主题，核对于2026-09-30。
- 使用页码：1

### dots-goal

- 文件：assets/dots-goal.webp
- [官方页面](https://chatgpt.com/features/dots/) · [原始图片/截图来源](https://images.ctfassets.net/8su2tbn87fck/koe4nuXekXUfuUGqiAPCS/d8985552b4a8b25fd758373a7e3e4953/bento_goal_desktop.png?fm=webp&q=80&w=1920)
- 类型：官方产品演示图；画面：Dot科学分析任务的活动列表：重跑分析、更新论文图、调查结果、修改解释、标记审核，以及暂停按钮
- 图片未标独立发布日期；关联DevDay主题，核对于2026-09-30。
- 使用页码：2

### space-prototype

- 文件：assets/space-prototype.webp
- [官方页面](https://chatgpt.com/features/space/) · [原始图片/截图来源](https://images.ctfassets.net/8su2tbn87fck/Z2uVjpDqSNUgScExYRlI2/df85340215bf6f11c2a9a534055506b0/module_3_Visualize-ideas-on-a-page_16x9.png?fm=webp&q=80&w=1600)
- 类型：官方产品演示图；画面：共享Page里的入职原型、协作者光标与侧栏
- 图片未标独立发布日期；关联DevDay主题，核对于2026-09-30。
- 使用页码：13

### slack-bug-pr

- 文件：assets/slack-bug-pr.webp
- [官方页面](https://chatgpt.com/features/chatgpt-in-slack-and-teams/) · [原始图片/截图来源](https://images.ctfassets.net/8su2tbn87fck/4YQiH31LwPclhAufMVKAkA/8dd6cd45436898bb0a4b46af07aa26ea/Module_4_Bug.png?fm=webp&q=80&w=1600)
- 类型：官方产品演示图；画面：Slack里调查checkout bug并打开修复PR
- 图片未标独立发布日期；关联DevDay主题，核对于2026-09-30。
- 使用页码：15

### plugin-surfaces

- 文件：assets/plugin-surfaces.webp
- [官方页面](https://developers.openai.com/plugins/build/extensions) · [原始图片/截图来源](https://developers.openai.com/images/apps-sdk/extensions/chatgpt-plugin-surfaces.webp)
- 类型：官方界面说明图；画面：插件可进入侧栏、设置、输入框、对话与侧面板
- 图片未标独立发布日期；关联DevDay主题，核对于2026-09-30。
- 使用页码：11

### sites-dashboard

- 文件：assets/sites-dashboard.webp
- [官方页面](https://chatgpt.com/features/sites/) · [原始图片/截图来源](https://images.ctfassets.net/8su2tbn87fck/5cazoGMi7ptb9qYZilKGlF/185ec65f2d7772c4c56507cab3e905a3/sites-usecase-team-dashboard-20260925-v2.png?fm=webp&q=80&w=1920)
- 类型：官方产品演示图；画面：Sites团队Dashboard示例；属于产品效果，非声称该仪表盘本身于大会发布
- 图片未标独立发布日期；关联DevDay主题，核对于2026-09-30。
- 使用页码：12

### codex-cloud-ui

- 文件：assets/codex-cloud-ui.png
- [官方页面](https://learn.chatgpt.com/docs/cloud) · [原始图片/截图来源](https://learn.chatgpt.com/docs/cloud)
- 类型：官方页面产品演示截图；画面：官方页面HTML演示：已发布云开发环境与任务输入框
- 图片未标独立发布日期；关联DevDay主题，核对于2026-09-30。
- 使用页码：7

### codex-cli-ui

- 文件：assets/codex-cli-ui.png
- [官方页面](https://learn.chatgpt.com/docs/codex/cli) · [原始图片/截图来源](https://learn.chatgpt.com/docs/codex/cli)
- 类型：官方页面产品演示截图；画面：官方文档HTML产品演示：GPT-6.1 Sol终端起始界面与命令列表；截图时动态输入框处于空状态
- 图片未标独立发布日期；关联DevDay主题，核对于2026-09-30。
- 使用页码：7

官方画面是产品宣传与文档示例，未经我们账户实际操作验证。原图未用AI重绘；结构、事件、录音和演示流程明确标为编辑示意。

## 大会与动态文档差异

- API Ultrafast 大会最高6×，动态文档最高8×；图采用大会口径。
- Profiles / Plugin extensions 的计划范围与实际 rollout 分别标注。
- Sol Ultrafast、Private Inference、协作幻灯片为未来状态；Decisions仍Limited Preview、Agents API为Beta。
