# OpenAI DevDay 2026 · 18张视觉版

含封面恰好18张1080×1440 PNG，完整覆盖美国时间2026-09-29大会官方回顾的25个产品主题。相近主题合页，较细的用量、接入与测试条件保留在随包附录。

官方画面覆盖Dots、Cloud/CLI、插件扩展、Sites、Space/Pages、Slack；其余内容采用数据对比和功能示意。图片未经AI重绘或伪造；实际来源、类型和画面含义见assets/manifest.json。示意图不冒充产品效果截图。

- output/publish.zip：18张图片、发布文案、完整来源、25主题覆盖及条件附录。
- output/editable-source.zip：可编辑HTML/CSS/SVG、story.json、官方素材和审阅记录。
- index.html：18张全套预览；output/overview.png为整体排版总览。
- story.json：主要文字、页序、来源与功能图数据；价格、评测等特定布局文本也在build.cjs中。
- visuals.cjs：10种可编辑功能图；由story.json的diagramData覆盖显示文本。
- coverage.md：25个官方标题对应新页码，并保留详细补充条件。
- sources.md：原文、完整事实对应表及本版使用的图源。
- research/announcement-index.json：官方25主题索引，用于构建逐项核验。
- review.md及output/qa.json：实际图检与自动检查记录。

重新生成需要Node.js、Python 3、Chrome/Chromium和可用的中文字体：

```sh
npm ci
npm run build
npm run render
# 逐页查看PNG和240px封面，更新review.md。
# 核对后将story.json的draft设为false，再build/render。
npm run package
```

浏览器可由CHROME_PATH指定。包中没有下载脚本、网页缓存、node_modules或过程预览图。工作区只保留本版最终成品、重建源文件和实际使用的8份官方素材；不再分三辑或另占核对页。
