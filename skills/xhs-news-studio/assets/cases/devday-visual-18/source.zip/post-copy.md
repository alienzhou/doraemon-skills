# OpenAI DevDay 2026：25个亮点，18张看完

9月29日的 OpenAI DevDay 2026，官方回顾列出的25个发布主题，这次全部放进18张图，含封面。

Dots 持续推进工作，GPT-6.1 Sol 把 Standard 输入与输出单价定为 Astra 的1/5；Ultrafast、新 Pro 档、企业私密处理也一起更新。

开发侧覆盖 Codex 云端、CLI、审查、安全、判断与执行 API、AWS 托管 Agent；插件侧新增原生入口、制作分发、Sites托管和事件自动化。

协作侧有 Space、Pages、幻灯片、团队任务、聊天入口和 Meetings；最后还有作品主页、ChatGPT登录用量与企业 Marketplace。

官方产品画面搭配数据图和流程示意。Beta、Preview、即将推出均保留，详细用量、资格和测试口径见附录。资料核对截至2026年9月30日。

#OpenAI #DevDay2026 #Codex #AI开发 #智能体

## 18张发布顺序

1. 01-cover.png
2. 02-dots.png
3. 03-sol-price.png
4. 04-sol-evals.png
5. 05-ultrafast-pro.png
6. 06-private-intelligence.png
7. 07-codex-cloud-cli.png
8. 08-review-security.png
9. 09-decisions-agents.png
10. 10-bedrock-agents.png
11. 11-plugin-experience.png
12. 12-sites-mcp-events.png
13. 13-space-pages.png
14. 14-collaborative-slides.png
15. 15-team-chat-tasks.png
16. 16-meetings.png
17. 17-profiles-signin.png
18. 18-marketplace.png

## 官方原文与补充

- [官方DevDay 2026回顾](https://openai.com/index/devday-2026-recap/)
- [全部亮点与条件](coverage.md)
- [来源与图片出处](sources.md)
