#!/usr/bin/env python3
"""Verify the current 18-page render and package image and editable archives."""
from pathlib import Path
import json, hashlib, zipfile, struct
root=Path(__file__).resolve().parent
def need(ok,msg):
    if not ok: raise SystemExit(msg)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
s=json.loads((root/'story.json').read_text());q=json.loads((root/'output/qa.json').read_text())
need(s['draft'] is False,'Complete factual and visual review before packaging')
need(len(s['pages'])==18<=s['maxImages'],'Image limit exceeded')
need(q['ok'] and len(q['results'])==18,'Layout checks failed')
need(all(x['type']!='synthetic' for x in s['sources']),'Fictional sources found')
for n,h in {**q['inputHashes'],**q['outputHashes']}.items():
    p=root/n;need(p.is_file() and digest(p)==h,'Stale or missing file: '+n)
need((root/'review.md').is_file() and len((root/'review.md').read_text())>80,'Actual visual review required')
names=json.loads((root/'pages.json').read_text());pngs=['output/'+str(Path(n).with_suffix('.png')) for n in names]
for n in pngs:
    b=(root/n).read_bytes();need(b[:8]==b'\x89PNG\r\n\x1a\n' and struct.unpack('>II',b[16:24])==(1080,1440),'Wrong PNG dimensions: '+n)
coverage=json.loads((root/'coverage.json').read_text())
need(coverage['topics']==25 and all(x['pages'] for x in coverage['items']),'Missing official topics')
def archive(target,pairs):
    with zipfile.ZipFile(root/target,'w',zipfile.ZIP_DEFLATED) as z:
        for n,arc in pairs:z.write(root/n,arc)
    with zipfile.ZipFile(root/target) as z:
        need(z.testzip() is None,'Archive corruption: '+target)
        need(set(z.namelist())=={a for _,a in pairs},'Archive file mismatch')
        for n,a in pairs:need(z.read(a)==(root/n).read_bytes(),'Archive differs: '+a)
    return {a:digest(root/n) for n,a in pairs}
publish=pngs+['post-copy.md','sources.md','coverage.md']
m=archive('output/publish.zip',[(n,Path(n).name) for n in publish])
(root/'output/manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
asset_manifest=json.loads((root/'assets/manifest.json').read_text())
source=['README.md','brief.md','review.md','story.json','design-plan.json','build.cjs','visuals.cjs','render.cjs','package.py','package.json','package-lock.json','style.css','index.html','pages.json','post-copy.md','sources.md','coverage.md','coverage.json','research/announcement-index.json','research/original-story.json','assets/manifest.json','output/qa.json',*names]
source+=['assets/'+a['file'] for a in asset_manifest['assets']]
m=archive('output/editable-source.zip',[(n,n) for n in source])
(root/'output/source-manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
print(f'Verified 18 publishing PNGs; {len(publish)} publishing files and {len(source)} editable files.')
print(root/'output/publish.zip');print(root/'output/editable-source.zip')
